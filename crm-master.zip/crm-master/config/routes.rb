Rails.application.routes.draw do
  

  resources :devices

  resources :notifications

  resources :messages

  resources :addresses
  resources :vehicles
  resources :opportunities, :accounts, :textnotes
  
  devise_for :users
  scope "/admin" do
    resources :users
  end
  
  root :to => 'passthrough#index'


  get 'accounts/:id/new_opportunity'                => 'opportunities#new'
  get ':object_type/:id/new_note'                   => 'textnotes#new'
  get 'nearestVehicle'                              => 'vehicles#nearestVehicle'
  get 'vehicleTrack'                                => 'vehicles#vehicleTrack'
  post 'convertTrackToArea'                         => 'vehicles#convertTrackToArea'
  get 'routeOptimization'                           => 'vehicles#routeOptimization'
  get 'routePlanner'                                => 'vehicles#routePlanner'  
  get 'importar'                                    => 'addresses#importar'
  post 'insert_addresses_to_WF'                     => 'addresses#insert_addresses_to_WF'
  post 'geocode_addresses'                          => 'addresses#geocode_addresses'



  get 'messages'                                    => 'messages#index'
  get 'messages/new'                                => 'messages#new'
  post 'messages'                                   => 'messages#create'
  get 'get_messages'                                => 'messages#get_messages'
  get 'get_vehicles/:id'                            => 'vehicles#get_vehicles'

  #Drivers
  get 'drivers'                                     => 'drivers#index'
  get 'get_drivers'                                 => 'drivers#get_drivers'
  get 'drivers_access'                              => 'drivers#drivers_access'
  post 'set_access'                                 => 'drivers#set_access'


  get 'read_card'                                   => 'drivers#read_card'
  post 'write_card'                                 => 'drivers#write_card'

  #Devices
  get   'configureRemoteAuxDevice/:id'                  => 'devices#configureRemoteAuxDevice'
  get   'removeRemoteAuxDeviceConfig/:id'               => 'devices#removeRemoteAuxDeviceConfig'
  post  'send_message_to_device'                        => 'devices#send_message_to_device'
  get   'devices/:id/verify_rfid_matches'               => 'devices#verify_rfid_matches'
  post  'devices/:id/verify_rfid_matches'               => 'devices#verify_rfid_matches'
  get   '/vehicle/:id/deleteAlldevices'                 => 'vehicles#deleteAllDevices'



  


  get 'update_wakeup_timers'                        => 'vehicles#update_wakeup_timers'


  get 'dashboard'                                   => 'dashboards#index'
  get 'rfid'                                        => 'dashboards#rfidDashboard'
  get 'temperature'                                 => 'dashboards#temperatureDashboard'
  get 'temperature2'                                => 'dashboards#temperatureDashboard2'




  # The priority is based upon order of creation: first created -> highest priority.
  # See how all your routes lay out with "rake routes".

  # You can have the root of your site routed with "root"
  # root 'welcome#index'

  # Example of regular route:
  #   get 'products/:id' => 'catalog#view'

  # Example of named route that can be invoked with purchase_url(id: product.id)
  #   get 'products/:id/purchase' => 'catalog#purchase', as: :purchase

  # Example resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Example resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Example resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Example resource route with more complex sub-resources:
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', on: :collection
  #     end
  #   end

  # Example resource route with concerns:
  #   concern :toggleable do
  #     post 'toggle'
  #   end
  #   resources :posts, concerns: :toggleable
  #   resources :photos, concerns: :toggleable

  # Example resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end
end
