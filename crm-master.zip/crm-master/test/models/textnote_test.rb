require 'test_helper'

class TextnoteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
