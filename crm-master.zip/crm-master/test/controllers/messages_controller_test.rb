require 'test_helper'

class MessagesControllerTest < ActionController::TestCase
  setup do
    @message = messages(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:messages)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create message" do
    assert_difference('Message.count') do
      post :create, message: { account_id: @message.account_id, created_at: @message.created_at, data: @message.data, latitude: @message.latitude, longitud: @message.longitud, message_time: @message.message_time, pos_time: @message.pos_time, source_device_address: @message.source_device_address, type: @message.type, updated_at: @message.updated_at, vehicle_id: @message.vehicle_id, wf_message_id: @message.wf_message_id }
    end

    assert_redirected_to message_path(assigns(:message))
  end

  test "should show message" do
    get :show, id: @message
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @message
    assert_response :success
  end

  test "should update message" do
    patch :update, id: @message, message: { account_id: @message.account_id, created_at: @message.created_at, data: @message.data, latitude: @message.latitude, longitud: @message.longitud, message_time: @message.message_time, pos_time: @message.pos_time, source_device_address: @message.source_device_address, type: @message.type, updated_at: @message.updated_at, vehicle_id: @message.vehicle_id, wf_message_id: @message.wf_message_id }
    assert_redirected_to message_path(assigns(:message))
  end

  test "should destroy message" do
    assert_difference('Message.count', -1) do
      delete :destroy, id: @message
    end

    assert_redirected_to messages_path
  end
end
