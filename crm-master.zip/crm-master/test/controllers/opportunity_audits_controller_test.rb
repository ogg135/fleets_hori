require 'test_helper'

class OpportunityAuditsControllerTest < ActionController::TestCase
  setup do
    @opportunity_audit = opportunity_audits(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:opportunity_audits)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create opportunity_audit" do
    assert_difference('OpportunityAudit.count') do
      post :create, opportunity_audit: {  }
    end

    assert_redirected_to opportunity_audit_path(assigns(:opportunity_audit))
  end

  test "should show opportunity_audit" do
    get :show, id: @opportunity_audit
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @opportunity_audit
    assert_response :success
  end

  test "should update opportunity_audit" do
    patch :update, id: @opportunity_audit, opportunity_audit: {  }
    assert_redirected_to opportunity_audit_path(assigns(:opportunity_audit))
  end

  test "should destroy opportunity_audit" do
    assert_difference('OpportunityAudit.count', -1) do
      delete :destroy, id: @opportunity_audit
    end

    assert_redirected_to opportunity_audits_path
  end
end
