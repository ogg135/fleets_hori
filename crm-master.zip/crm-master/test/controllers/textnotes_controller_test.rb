require 'test_helper'

class TextnotesControllerTest < ActionController::TestCase
  setup do
    @textnote = textnotes(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:textnotes)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create textnote" do
    assert_difference('Textnote.count') do
      post :create, textnote: { account_id: @textnote.account_id, created_by: @textnote.created_by, description: @textnote.description, opportunity_id: @textnote.opportunity_id, title: @textnote.title, updated_by: @textnote.updated_by, user_id: @textnote.user_id }
    end

    assert_redirected_to textnote_path(assigns(:textnote))
  end

  test "should show textnote" do
    get :show, id: @textnote
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @textnote
    assert_response :success
  end

  test "should update textnote" do
    patch :update, id: @textnote, textnote: { account_id: @textnote.account_id, created_by: @textnote.created_by, description: @textnote.description, opportunity_id: @textnote.opportunity_id, title: @textnote.title, updated_by: @textnote.updated_by, user_id: @textnote.user_id }
    assert_redirected_to textnote_path(assigns(:textnote))
  end

  test "should destroy textnote" do
    assert_difference('Textnote.count', -1) do
      delete :destroy, id: @textnote
    end

    assert_redirected_to textnotes_path
  end
end
