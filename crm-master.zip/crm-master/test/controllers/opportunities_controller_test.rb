require 'test_helper'

class OpportunitiesControllerTest < ActionController::TestCase
  setup do
    @opportunity = opportunities(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:opportunities)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create opportunity" do
    assert_difference('Opportunity.count') do
      post :create, opportunity: { account_id: @opportunity.account_id, amount: @opportunity.amount, close_date: @opportunity.close_date, created_at: @opportunity.created_at, created_by: @opportunity.created_by, description: @opportunity.description, name: @opportunity.name, stage: @opportunity.stage, type: @opportunity.type, updated_at: @opportunity.updated_at, updated_by: @opportunity.updated_by, user_id: @opportunity.user_id }
    end

    assert_redirected_to opportunity_path(assigns(:opportunity))
  end

  test "should show opportunity" do
    get :show, id: @opportunity
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @opportunity
    assert_response :success
  end

  test "should update opportunity" do
    patch :update, id: @opportunity, opportunity: { account_id: @opportunity.account_id, amount: @opportunity.amount, close_date: @opportunity.close_date, created_at: @opportunity.created_at, created_by: @opportunity.created_by, description: @opportunity.description, name: @opportunity.name, stage: @opportunity.stage, type: @opportunity.type, updated_at: @opportunity.updated_at, updated_by: @opportunity.updated_by, user_id: @opportunity.user_id }
    assert_redirected_to opportunity_path(assigns(:opportunity))
  end

  test "should destroy opportunity" do
    assert_difference('Opportunity.count', -1) do
      delete :destroy, id: @opportunity
    end

    assert_redirected_to opportunities_path
  end
end
