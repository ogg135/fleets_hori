require 'test_helper'

class OpportunityAuditsHelperTest < ActionView::TestCase
end
