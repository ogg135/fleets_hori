require 'test_helper'

class TextnotesHelperTest < ActionView::TestCase
end
