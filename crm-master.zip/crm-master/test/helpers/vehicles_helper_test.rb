require 'test_helper'

class VehiclesHelperTest < ActionView::TestCase
end
