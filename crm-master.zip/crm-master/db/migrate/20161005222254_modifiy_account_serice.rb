class ModifiyAccountSerice < ActiveRecord::Migration
  def change
  	rename_column :accounts, :service_temperature?, :service_temperature
  end
end
