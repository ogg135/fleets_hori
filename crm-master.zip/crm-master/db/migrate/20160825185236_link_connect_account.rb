class LinkConnectAccount < ActiveRecord::Migration
  def change
  	add_column :accounts, :wf_link_connect_account, :boolean, default: false
  end
end
