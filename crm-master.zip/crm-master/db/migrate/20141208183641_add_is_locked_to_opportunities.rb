class AddIsLockedToOpportunities < ActiveRecord::Migration
  def change
  	add_column :opportunities, :isLocked, :boolean
  end
end
