class ConvertMessageVehicleIdToInt < ActiveRecord::Migration
  def change
  	change_column :messages, :vehicle_id, 'integer USING CAST(vehicle_id AS integer)'
  end
end
