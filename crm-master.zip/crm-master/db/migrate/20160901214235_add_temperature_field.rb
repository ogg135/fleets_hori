class AddTemperatureField < ActiveRecord::Migration
  def change
  	add_column :messages, :temperature_C, :decimal, precision: 5, scale: 2
  end
end
