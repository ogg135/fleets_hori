class ChangeDeviceLastMsgDateTimeType < ActiveRecord::Migration
  def change
  	remove_column 	:devices, :last_message_received_datetime
  	add_column		:devices, :last_message_received_datetime, :datetime
  end
end
