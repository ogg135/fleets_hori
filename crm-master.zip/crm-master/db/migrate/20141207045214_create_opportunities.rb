class CreateOpportunities < ActiveRecord::Migration
  def change
    create_table :opportunities do |t|
      t.string :name,           null: false
      t.integer :amount,        null: false
      t.string :description
      t.string :stage
      t.date :close_date,       null: false, default: Date.today+30
      t.integer :account_id
      t.integer :user_id
      t.string :type
      t.integer :created_by,    null: false
      t.integer :updated_by,    null: false

      t.timestamps
    end
  end
end
