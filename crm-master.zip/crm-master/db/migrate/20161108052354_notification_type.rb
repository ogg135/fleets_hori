class NotificationType < ActiveRecord::Migration
  def change
  	add_column :notifications, :tag, :string
  end
end
