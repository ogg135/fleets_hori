class CreateAccounts < ActiveRecord::Migration
  def change
    create_table :accounts do |t|
      t.integer :created_by
      t.string :name
      t.string :external_id
      t.integer :owner
      t.string :website
      t.string :email
      t.string :phone
      t.integer :updated_by

      t.timestamps
    end
  end
end
