class TemperatureAddOns < ActiveRecord::Migration
  def change
  	add_column :accounts, :temperature_min_threshold, :decimal, precision: 5, scale: 2
  	add_column :accounts, :temperature_max_threshold, :decimal, precision: 5, scale: 2
  	add_column :accounts, :temperature_create_notification_if_out_of_threshold, :boolean, default: false
  	add_column :accounts, :temperature_send_email_notification, :boolean, default: false
  end
end
