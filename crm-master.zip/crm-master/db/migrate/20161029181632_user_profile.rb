class UserProfile < ActiveRecord::Migration
  def change
  	change_column_default :users, :profile, 'toolbox'
  end
end
