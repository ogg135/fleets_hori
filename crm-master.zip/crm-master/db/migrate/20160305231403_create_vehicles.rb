class CreateVehicles < ActiveRecord::Migration
  def change
    create_table :vehicles do |t|
      t.string :objectno
      t.string :objectname

      t.timestamps
    end
  end
end
