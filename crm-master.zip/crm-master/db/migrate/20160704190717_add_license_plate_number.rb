class AddLicensePlateNumber < ActiveRecord::Migration
  def change
  	add_column :vehicles, :licenseplatenumber, 		:string, length: { maximum: 20 }
  end
end
