class CreateDrivers < ActiveRecord::Migration
  def change
    create_table :drivers do |t|
      t.string :name1
      t.string :driveruid
      t.string :driver_key

      t.timestamps
    end

    add_column :accounts, :wf_import_drivers, 		:boolean, default: false
  end
end


