class RenameMessageType < ActiveRecord::Migration
  def change
  	rename_column :messages, :type, :device_type
  end
end
