class AddMessageTimeAddObjectNo < ActiveRecord::Migration
  def change
  	add_column :messages, :objectno, :string
  	add_column :notifications, :message_time, :datetime
  end
end
