class AddAccountTemperatureCreateNotificationTimer < ActiveRecord::Migration
  def change
  	add_column :accounts, :temperature_notification_timer, :integer, default: 1, after: :temperature_create_notification_if_out_of_threshold
  end
end
