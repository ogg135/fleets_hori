class AddAccounttoDrivers < ActiveRecord::Migration
  def change
  	add_column :drivers, :account_id,		:integer
  end
end
