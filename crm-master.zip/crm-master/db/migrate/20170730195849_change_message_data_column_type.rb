class ChangeMessageDataColumnType < ActiveRecord::Migration
  def change
  	change_column :messages, :data, :text, :limit => nil
  end
end
