class CreateNotifications < ActiveRecord::Migration
  def change
    create_table :notifications do |t|
    	t.integer 	:account_id
    	t.integer 	:vehicle_id
    	t.string 	:objectno
    	t.datetime 	:pos_time
    	t.string 	:latitude
    	t.string 	:longitude
    	t.string 	:event_level
    	t.string 	:text
    	t.string 	:recipients

      	t.timestamps
    end
  end
end
