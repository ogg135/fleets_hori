class CreateTextnotes < ActiveRecord::Migration
  def change
    create_table :textnotes do |t|
      t.string :title
      t.string :description
      t.integer :user_id
      t.integer :opportunity_id
      t.integer :account_id
      t.integer :created_by
      t.integer :updated_by
      t.datetime :deleted_at

      t.timestamps
    end

    add_index :textnotes, :deleted_at
  end
end
