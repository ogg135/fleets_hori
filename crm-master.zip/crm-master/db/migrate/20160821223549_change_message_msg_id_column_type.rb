class ChangeMessageMsgIdColumnType < ActiveRecord::Migration
  def change
  	change_column :messages, :wf_message_id, :string
  end
end
