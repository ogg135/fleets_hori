class CreateOpportunityAudits < ActiveRecord::Migration
  def self.up
  	create_table :opportunity_audits do |t|
      t.integer :opportunity_id
      t.string 	:field
      t.string 	:old_value
      t.string	:new_value
      t.integer	:user_id

      t.timestamps
    end
  end

  def self.down
  	drop_table :opportunity_audit
  end
end
