class AddObjectuidObjecttype < ActiveRecord::Migration
  def change
    add_column :vehicles, :account_id,		:integer
    add_column :vehicles, :objectuid,  		:string, length: { maximum: 30 }
    add_column :vehicles, :objecttype, 		:string
    add_column :vehicles, :longitude,  		:string
    add_column :vehicles, :latitude,   		:string
    add_column :vehicles, :longitude_mdeg,  :integer
    add_column :vehicles, :latitude_mdeg,   :integer
    add_column :vehicles, :pos_time, 		:datetime
    add_column :vehicles, :status, 			:string
    add_column :vehicles, :driveruid, 		:string, length: { maximum: 30 }
 
  end
end
