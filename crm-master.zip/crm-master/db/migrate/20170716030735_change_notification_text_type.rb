class ChangeNotificationTextType < ActiveRecord::Migration
  def change
  	change_column :notifications, :text, :text, :limit => nil
  end
end
