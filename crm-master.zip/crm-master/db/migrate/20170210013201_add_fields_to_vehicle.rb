class AddFieldsToVehicle < ActiveRecord::Migration
  def change
  	remove_column 	:vehicles, :temperature_sensor
  	add_column		:vehicles, :LINK_530_SN, :string, lenght: 12
  	add_column		:vehicles, :LINK_530_MAC_address, :string
  end
end
