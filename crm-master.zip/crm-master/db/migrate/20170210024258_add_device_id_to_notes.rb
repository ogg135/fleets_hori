class AddDeviceIdToNotes < ActiveRecord::Migration
  def change
  	add_column		:textnotes, :device_id, :integer
  end
end
