class AddAccountServices < ActiveRecord::Migration
  def change
  	add_column :accounts, :service_temperature?, :boolean, default: false
  end
end
