class DeleteDeviceFields < ActiveRecord::Migration
  def change
  	remove_column :devices, :account_id
  	remove_column :devices, :LINK_530_SN
  	remove_column :devices, :LINK_530_MAC_address
  end
end
