class AddTemperatureCheckToVehicle < ActiveRecord::Migration
  def change
  	add_column :vehicles, :temperature_sensor, :boolean, default: false
  end
end
