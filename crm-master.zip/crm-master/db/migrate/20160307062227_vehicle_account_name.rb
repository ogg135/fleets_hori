class VehicleAccountName < ActiveRecord::Migration
  def change
  	add_column :vehicles, :account_name, :string
  end
end
