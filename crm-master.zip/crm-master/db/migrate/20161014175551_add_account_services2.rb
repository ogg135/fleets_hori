class AddAccountServices2 < ActiveRecord::Migration
  def change
  	add_column :accounts, :service_vehicle_track, :boolean, default: false
  	add_column :accounts, :service_convert_track_into_area, :boolean, default: false
  end
end
