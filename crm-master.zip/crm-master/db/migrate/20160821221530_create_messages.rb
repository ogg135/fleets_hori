class CreateMessages < ActiveRecord::Migration
  def change
    create_table :messages do |t|
      t.integer :account_id
      t.string :vehicle_id
      t.integer :wf_message_id
      t.datetime :message_time
      t.string :data
      t.string :type
      t.datetime :created_at
      t.datetime :updated_at
      t.string :longitud
      t.string :latitude
      t.datetime :pos_time
      t.string :source_device_address

      t.timestamps
    end
  end
end
