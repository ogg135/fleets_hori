class RenameUserAdmin < ActiveRecord::Migration
  def change
  	rename_column :users, :isAdmin, :admin
  end
end
