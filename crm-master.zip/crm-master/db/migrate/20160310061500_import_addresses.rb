class ImportAddresses < ActiveRecord::Migration
  def change
  	add_column :accounts, :wf_import_addresses, 		:boolean, default: false
  end
end
