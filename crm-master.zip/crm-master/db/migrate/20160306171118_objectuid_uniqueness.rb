class ObjectuidUniqueness < ActiveRecord::Migration
  def change
  	add_index :vehicles, :objectuid, :unique => true
  end
end
