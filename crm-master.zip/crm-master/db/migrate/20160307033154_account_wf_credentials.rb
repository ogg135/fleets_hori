class AccountWfCredentials < ActiveRecord::Migration
  def change
  	add_column :accounts, :wf_account_name, 		:string, unique: true
  	add_column :accounts, :wf_username, 			:string
  	add_column :accounts, :wf_password, 			:string
  	add_column :accounts, :wf_apikey, 				:string
  	add_column :accounts, :wf_import_vehicles, 		:boolean, default: false
  end
end
