class CreateAddresses < ActiveRecord::Migration
  def change
    create_table :addresses do |t|
      t.string :addrnr, length: { maximum: 10 }
      t.string :addruid,  length: { maximum: 30 }
      t.string :addrname1
      t.integer :radius
      t.integer :positiony
      t.integer :positionx
      t.string :mapcode
      t.integer :account_id

      t.timestamps
    end

    add_index :addresses, :addruid, :unique => true
  end
end
