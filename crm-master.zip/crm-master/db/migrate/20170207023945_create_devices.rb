class CreateDevices < ActiveRecord::Migration
  def change
    create_table :devices do |t|
      t.string :product
      t.string :name
      t.string :SN
      t.string :MAC_address
      t.string :HW_version
      t.string :FW_version
      t.integer :account_id
      t.integer :vehicle_id
      t.string :LINK_530_SN
      t.string :LINK_530_MAC_address
      t.integer :last_message_received
      t.string :last_message_received_datetime
      t.integer :created_by
      t.integer :updated_by

      t.timestamps
    end
  end
end
