# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20170811012235) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "accounts", force: true do |t|
    t.integer  "created_by"
    t.string   "name"
    t.string   "external_id"
    t.integer  "owner"
    t.string   "website"
    t.string   "email"
    t.string   "phone"
    t.integer  "updated_by"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.datetime "deleted_at"
    t.string   "wf_account_name"
    t.string   "wf_username"
    t.string   "wf_password"
    t.string   "wf_apikey"
    t.boolean  "wf_import_vehicles",                                                          default: false
    t.boolean  "wf_import_addresses",                                                         default: false
    t.boolean  "wf_link_connect_account",                                                     default: false
    t.boolean  "service_temperature",                                                         default: false
    t.decimal  "temperature_min_threshold",                           precision: 5, scale: 2
    t.decimal  "temperature_max_threshold",                           precision: 5, scale: 2
    t.boolean  "temperature_create_notification_if_out_of_threshold",                         default: false
    t.boolean  "temperature_send_email_notification",                                         default: false
    t.boolean  "service_vehicle_track",                                                       default: false
    t.boolean  "service_convert_track_into_area",                                             default: false
    t.integer  "temperature_notification_timer",                                              default: 1
    t.boolean  "wf_import_drivers",                                                           default: false
  end

  add_index "accounts", ["deleted_at"], name: "index_accounts_on_deleted_at", using: :btree

  create_table "addresses", force: true do |t|
    t.string   "addrnr"
    t.string   "addruid"
    t.string   "addrname1"
    t.integer  "radius"
    t.integer  "positiony"
    t.integer  "positionx"
    t.string   "mapcode"
    t.integer  "account_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "addresses", ["addruid"], name: "index_addresses_on_addruid", unique: true, using: :btree

  create_table "devices", force: true do |t|
    t.string   "product"
    t.string   "name"
    t.string   "SN"
    t.string   "MAC_address"
    t.string   "HW_version"
    t.string   "FW_version"
    t.integer  "vehicle_id"
    t.integer  "last_message_received"
    t.integer  "created_by"
    t.integer  "updated_by"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.datetime "last_message_received_datetime"
  end

  create_table "drivers", force: true do |t|
    t.string   "name1"
    t.string   "driveruid"
    t.string   "driver_key"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "account_id"
  end

  create_table "messages", force: true do |t|
    t.integer  "account_id"
    t.integer  "vehicle_id"
    t.string   "wf_message_id"
    t.datetime "message_time"
    t.text     "data"
    t.string   "device_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "longitud"
    t.string   "latitude"
    t.datetime "pos_time"
    t.string   "source_device_address"
    t.decimal  "temperature_C",         precision: 5, scale: 2
    t.string   "objectno"
  end

  create_table "notifications", force: true do |t|
    t.integer  "account_id"
    t.integer  "vehicle_id"
    t.string   "objectno"
    t.datetime "pos_time"
    t.string   "latitude"
    t.string   "longitude"
    t.string   "event_level"
    t.text     "text"
    t.string   "recipients"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.datetime "message_time"
    t.string   "tag"
    t.integer  "device_id"
    t.integer  "created_by"
  end

  create_table "opportunities", force: true do |t|
    t.string   "name",                               null: false
    t.integer  "amount",                             null: false
    t.string   "description"
    t.string   "stage"
    t.date     "close_date",  default: '2016-04-04', null: false
    t.integer  "account_id"
    t.integer  "user_id"
    t.string   "type"
    t.integer  "created_by",                         null: false
    t.integer  "updated_by",                         null: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.datetime "deleted_at"
    t.boolean  "isLocked"
  end

  add_index "opportunities", ["deleted_at"], name: "index_opportunities_on_deleted_at", using: :btree

  create_table "opportunity_audits", force: true do |t|
    t.integer  "opportunity_id"
    t.string   "field"
    t.string   "old_value"
    t.string   "new_value"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "textnotes", force: true do |t|
    t.string   "title"
    t.string   "description"
    t.integer  "user_id"
    t.integer  "opportunity_id"
    t.integer  "account_id"
    t.integer  "created_by"
    t.integer  "updated_by"
    t.datetime "deleted_at"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "device_id"
  end

  add_index "textnotes", ["deleted_at"], name: "index_textnotes_on_deleted_at", using: :btree

  create_table "users", force: true do |t|
    t.string   "email",                  default: "",        null: false
    t.string   "encrypted_password",     default: "",        null: false
    t.string   "first_name",             default: "",        null: false
    t.string   "last_name",              default: "",        null: false
    t.string   "profile",                default: "toolbox"
    t.boolean  "admin",                  default: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",          default: 0,         null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet     "current_sign_in_ip"
    t.inet     "last_sign_in_ip"
    t.datetime "deleted_at"
    t.integer  "account_id"
  end

  add_index "users", ["deleted_at"], name: "index_users_on_deleted_at", using: :btree
  add_index "users", ["email"], name: "index_users_on_email", unique: true, using: :btree
  add_index "users", ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree

  create_table "vehicles", force: true do |t|
    t.string   "objectno"
    t.string   "objectname"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "account_id"
    t.string   "objectuid"
    t.string   "objecttype"
    t.string   "longitude"
    t.string   "latitude"
    t.integer  "longitude_mdeg"
    t.integer  "latitude_mdeg"
    t.datetime "pos_time"
    t.string   "status"
    t.string   "driveruid"
    t.string   "account_name"
    t.string   "licenseplatenumber"
    t.string   "LINK_530_SN"
    t.string   "LINK_530_MAC_address"
  end

  add_index "vehicles", ["objectuid"], name: "index_vehicles_on_objectuid", unique: true, using: :btree

end
