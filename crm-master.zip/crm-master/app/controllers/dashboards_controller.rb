class DashboardsController < ApplicationController
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

  before_action :authenticate_user!

  def index
  	@closed_won_opportunities_amount_this_month = Opportunity.where(stage: "Ganada").sum(:amount)
  	@closed_won_opportunities_count_this_month = Opportunity.where(stage: "Ganada").count
  	@average = @closed_won_opportunities_amount_this_month/@closed_won_opportunities_count_this_month

  	@closed_won_opportunities_amount_this_year = Opportunity.where(stage: "Ganada").group_by_month(:close_date).sum(:amount)
  end

  def rfidDashboard
    #@account = Account.find(id: current_user.account_id)
    @account = Account.find(current_user.account_id)
    @vehicles = Vehicle.where(account_id: current_user.account.id ).order(pos_time: :asc)
    @drivers = Driver.where(account_id: current_user.account.id ).order(name1: :asc)
  end

  def temperatureDashboard
    if params[:message_time].present?
    else
      params[:message_time] ='2'
      params[:group_by]     ='minute'
    end

    if current_user.admin?
        @vehicles                 = Message.select(:objectno).distinct
        if params[:objectno].present?
          @messages               = Message.temperature.where("message_time >= :date", :date => params[:message_time].to_i.hours.ago).where(objectno: params[:objectno].to_s)
        else
          @messages               = Message.temperature.where("message_time >= :date", :date => params[:message_time].to_i.hours.ago)          
        end
        @messagesGROUPED          = @messages.group(:objectno)
        @messagesMAX              = @messagesGROUPED.maximum(:temperature_C)
        @messagesMIN              = @messagesGROUPED.minimum(:temperature_C)
        @messagesGRAPH            = @messagesGROUPED.group_by_period(params[:group_by], :message_time, permit: %w[hour minute]).median(:temperature_C)
        @notificationsQty         = Notification.tag("Temperature").where("message_time >= :date", :date => params[:message_time].to_i.hours.ago).group(:objectno).count
        @temperatureLastTimeValue = Message.temperature.last.message_time

    else
        @vehicles                 = Message.temperature.where(account_id: current_user.account_id).select(:objectno).distinct
        if params[:objectno].present?
          @messages               = Message.temperature.where(account_id: current_user.account_id).where("message_time >= :date", :date => params[:message_time].to_i.hours.ago).where(objectno: params[:objectno].to_s)
        else
          @messages               = Message.temperature.where(account_id: current_user.account_id).where("message_time >= :date", :date => params[:message_time].to_i.hours.ago)          
        end
        @messagesGROUPED          = @messages.group(:objectno)
        @messagesMAX              = @messagesGROUPED.maximum(:temperature_C)
        @messagesMIN              = @messagesGROUPED.minimum(:temperature_C)
        @messagesGRAPH            = @messagesGROUPED.group_by_period(params[:group_by], :message_time, permit: %w[hour minute]).median(:temperature_C) 
        @notificationsQty         = Notification.tag("Temperature").where(account_id: current_user.account_id).where("message_time >= :date", :date => params[:message_time].to_i.hours.ago).group(:objectno).count
        @temperatureLastTimeValue = Message.temperature.where(account_id: current_user.account_id).last.message_time
    end
    
    #Fill hash with max and min values for each vehicle
    @messagesMAXMIN               = Hash.new
    @messagesMIN.each {|key,value| 
      if Vehicle.where(objectno: key).take.account.temperature_max_threshold? 
        maxthreshold = Vehicle.where(objectno: key).take.account.temperature_max_threshold 
      end
      if Vehicle.where(objectno: key).take.account.temperature_min_threshold? 
        minthreshold = Vehicle.where(objectno: key).take.account.temperature_min_threshold 
      end

      max = @messagesMAX[key]
      notifications = @notificationsQty[key]
      @messagesMAXMIN [key]=[max,maxthreshold,value,minthreshold,notifications]
    }  

    #Create CSV
    respond_to do |format|
      format.html
      format.csv { send_data @messages.to_csv }
    end
  end

  #BETA Feature
  def temperatureDashboard2

    #If user is admin
    if current_user.admin?
        @vehicles                 = Message.select(:objectno).distinct
        p @vehicles
        if params[:search].present?
          p "Search presente"
          params[:objectno] = params[:search]

          p params[:objectno]
          p params[:rangefrom_string]
          @messages               = Message.temperature.where("message_time::date = ?",  params[:rangefrom_string]).where(objectno: params[:objectno].to_s)
          p @messages
          
          #@messages               = Message.temperature.where("message_time >= :date", :date => params[:date].to_i.hours.ago).where(objectno: params[:objectno].to_s)
        else
          @messages               = Message.temperature.where("message_time::date = ?", Date.today)          
        end

        @messagesGROUPED          = @messages.group(:objectno)
        @messagesMAX              = @messagesGROUPED.maximum(:temperature_C)
        @messagesMIN              = @messagesGROUPED.minimum(:temperature_C)
        @messagesGRAPH            = @messagesGROUPED.group_by_period('minute', :message_time, permit: %w[hour minute]).median(:temperature_C)
        @notificationsQty         = Notification.tag("Temperature").where("message_time::date = ?",  params[:rangefrom_string]).group(:objectno).count
        @temperatureLastTimeValue = Message.temperature.last.message_time

    #If user is not admin
    else
        @vehicles                 = Message.temperature.where(account_id: current_user.account_id).select(:objectno).distinct
        if params[:objectno].present?
          @messages               = Message.temperature.where(account_id: current_user.account_id).where("message_time >= :date", :date => params[:message_time].to_i.hours.ago).where(objectno: params[:objectno].to_s)
        else
          @messages               = Message.temperature.where(account_id: current_user.account_id).where("message_time >= :date", :date => params[:message_time].to_i.hours.ago)          
        end
        @messagesGROUPED          = @messages.group(:objectno)
        @messagesMAX              = @messagesGROUPED.maximum(:temperature_C)
        @messagesMIN              = @messagesGROUPED.minimum(:temperature_C)
        @messagesGRAPH            = @messagesGROUPED.group_by_period(params[:group_by], :message_time, permit: %w[hour minute]).median(:temperature_C) 
        @notificationsQty         = Notification.tag("Temperature").where(account_id: current_user.account_id).where("message_time >= :date", :date => params[:message_time].to_i.hours.ago).group(:objectno).count
        @temperatureLastTimeValue = Message.temperature.where(account_id: current_user.account_id).last.message_time
    end
    
    #Fill hash with max and min values for each vehicle
    @messagesMAXMIN               = Hash.new
    @messagesMIN.each {|key,value| 
      if Vehicle.where(objectno: key).take.account.temperature_max_threshold? 
        maxthreshold = Vehicle.where(objectno: key).take.account.temperature_max_threshold 
      end
      if Vehicle.where(objectno: key).take.account.temperature_min_threshold? 
        minthreshold = Vehicle.where(objectno: key).take.account.temperature_min_threshold 
      end

      max = @messagesMAX[key]
      notifications = @notificationsQty[key]
      @messagesMAXMIN [key]=[max,maxthreshold,value,minthreshold,notifications]
    }  

    #Create CSV
    respond_to do |format|
      format.html
      format.csv { send_data @messages.to_csv }
    end
  end
end
