# passthrough_controller.rb
class PassthroughController < ApplicationController
  def index
    path = case current_user.profile
      when 'temperature'
        temperature_path
      when 'RFID'
        vehicles_path
      when 'toolbox'
        vehicleTrack_path
      when 'admin'
        temperature_path
      else
        # If you want to raise an exception or have a default root for users without roles
    end

    redirect_to path     
  end
end