class TextnotesController < ApplicationController
  before_action :set_textnote, only: [:show, :edit, :update, :destroy]
  before_filter :admin_user

  respond_to :html

  def index
    @textnotes = Textnote.all
    respond_with(@textnotes)
  end

  def show
    respond_with(@textnote)
  end

  def new
    @textnote                 = Textnote.new

    session[:object_type] = params[:object_type]
    session[:id]          = params[:id]

    case session[:object_type]
      when "devices"
        @device = Device.find(params[:id])
        @textnote.device_id      = @device.id
      when "accounts"
        @account = Account.find(params[:id])
        @textnote.account_id      = @account.id
      when "opportunities"
        @opportunity = Opportunity.find(params[:id])
        @account = Account.find(@opportunity.account_id)
        @textnote.opportunity_id  = @opportunity.id
    end
    
    respond_with(@textnote)
  end

  def edit

  end

  def create
    @textnote             = Textnote.new(textnote_params)
    @textnote.created_by  = current_user.id
    @textnote.updated_by  = current_user.id
    @textnote.user_id     = current_user.id

    case session[:object_type]
      when "devices"
        @device = Device.find(session[:id])
        @textnote.device_id      = @device.id
      when "accounts"
        @account = Account.find(session[:id])
        @textnote.account_id      = @account.id
      when "opportunities"
        @opportunity = Opportunity.find(session[:id])
        @textnote.opportunity_id  = @opportunity.id  
        @textnote.account_id      = @opportunity.account_id   
    end

    @textnote.save

    #Redirigir al tipo de objecto correpondiente: Cuenta u Oportunidad
    respond_to do |format|
      if @textnote.save
        case session[:object_type]
        when "devices"
          format.html { redirect_to @device, notice: 'La nota fue creada exitosamente.' }
          format.json { render :show, status: :created, location: @device }
        when "accounts"
          format.html { redirect_to @account, notice: 'La nota fue creada exitosamente.' }
          format.json { render :show, status: :created, location: @account }
        when "opportunities"
          format.html { redirect_to @opportunity, notice: 'La nota fue creada exitosamente.' }
          format.json { render :show, status: :created, location: @opportunity }
        end
      else
        format.html { render :new }
        format.json { render json: @textnote.errors, status: :unprocessable_entity }
      end
    end

    session[:object_type]   = nil
    session[:id]            = nil


  end

  def update
    @textnote.updated_by  = current_user.id
    @textnote.update(textnote_params)
    respond_with(@textnote)
  end

  def destroy
    @textnote.destroy
    unless @textnote.device_id.nil?
      respond_with(Device.find(@textnote.device_id))
    end
    unless @textnote.account_id.nil?
      respond_with(Account.find(@textnote.account_id))
    end

    unless @textnote.opportunity_id.nil?
      respond_with(Opportunity.find(@textnote.opportunity_id))
    end
     
  end

  private
    def set_textnote
      @textnote = Textnote.find(params[:id])
    end

    def textnote_params
      params.require(:textnote).permit(:title, :description, :user_id, :opportunity_id, :account_id, :device_id, :created_by, :updated_by)
    end
end
