class DevicesController < ApplicationController
  before_action :set_device, only: [:show, :edit, :update, :destroy]
  before_filter :admin_user, only: [:index, :configureRemoteAuxDevice, :removeRemoteAuxDeviceConfig, :verify_rfid_matches, :new, :edit, :create, :update, :destroy]


  respond_to :html

  def index
    @devices      = Device.all
    @devices_ice  = @devices.where(product: 'ICE-BT530')
    @devices_rfid = @devices.where(product: 'RFID-BT530')

    
    respond_to do |format|
      format.html
      format.csv { send_data @devices.to_csv }
    end
  end

  def show
    @notes          = Textnote.where(device_id: @device.id)
    @notifications  = Notification.where(device_id: @device.id).last(5).reverse
    respond_with(@device)

    #Recent items
    session[:recent_items] ||= Array.new     
    session[:recent_items].unshift("type" => "devices", "id" => @device.id, "name" => @device.name) 
    session[:recent_items] = session[:recent_items].uniq.first(5)
  end

  def configureRemoteAuxDevice
    @device = Device.find(params[:id])
    account = Account.find(@device.vehicle.account_id)

    #Get free configid
    configid_url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=getRemoteAuxDeviceConfig&objectno="+@device.vehicle.objectno+"&outputformat=json&columnfilter=configid,deviceid,channel")
    response = HTTP.get(configid_url)
    @hash = JSON.parse response

    if @hash.present?
      if @hash.size >= 4
        #There are already 4 devices - device will not be created
        @notice = "Ya existen 4 dispositivos asociados a este vehiculo, no fue posible agregarlo."
      else
        (0..4).each do |i|
          result = @hash.select {|aux_device| aux_device["configid"] == i }
          
          if result.empty?
            @configid = i
            break
          end  
        end 

        #Enough space to create a new device, now will check for MAC address duplicity
        result2 = @hash.select {|aux_device| aux_device["deviceid"] == @device.MAC_address }
        p result2 

        if result2.empty?
          #Find a free channel
          (5..2).each do |i|
            result3 = @hash.select {|aux_device| aux_device["channel"] == i }
            if result3.empty?
              @channel = i
              break
            end  
          end

          #SPP Authentication
          url2 = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=configureLocalAuxDevice&objectno="+@device.vehicle.objectno+"&authentication=1&addgpsfix=1&addtimestamp=1")
          p url2
          response2 = HTTP.get(url2)

          url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=configureRemoteAuxDevice&objectno="+@device.vehicle.objectno+"&configid="+@configid.to_s+"&deviceid="+@device.MAC_address+"&friendlyname="+@device.name+"&servicename=SPP&channel="+@channel.to_s+"&pin=1234&sppbuffersize=512&sppflushtimeout=500&outputformat=json")
          p url
          response = HTTP.get(url)
          @hash = JSON.parse response
          p @hash

          if @hash.present?
            if @hash['errorcode'] == 28009
              @notice = "No se ha habilitado el servicio de LINK Connect (pestana de terceros) para este vehiculo."
            end
          else
            p "hash vacio"
            @notice = "El dispositivo fue creado exitosamente"
          end
        else
          @notice = "Ya existe un dispositivo con este MAC Address registrado en este vehiculo."
        end
      end
    #No devices registered at all - device will be created
    else
      @configid = "0"
      #Find a free channel
      (5..2).each do |i|
        result3 = @hash.select {|aux_device| aux_device["channel"] == i }
        if result3.empty?
          @channel = i
          break
        end  
      end

      #SPP Authentication
      url2 = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=configureLocalAuxDevice&objectno="+@device.vehicle.objectno+"&authentication=1")
      p url2
      response2 = HTTP.get(url2)

      #Register Bluetooth device on 3rd party window
      url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=configureRemoteAuxDevice&objectno="+@device.vehicle.objectno+"&configid="+@configid.to_s+"&deviceid="+@device.MAC_address+"&friendlyname="+@device.name+"&servicename=SPP&authentication=1&channel="+@channel.to_s+"&pin=1234&sppbuffersize=512&sppflushtimeout=500&outputformat=json")

      p url
      response = HTTP.get(url)
      @hash = JSON.parse response
      p @hash

      if @hash.present?
        if @hash['errorCode'] == 28009
          @notice = "No se ha habilitado el servicio de LINK Connect (pestaña de terceros) para este vehiculo. Por favor contacte a SASU (Sales Support) de TomTom Telematics."
        end
      else
        p "hash vacio"
        @notice = "El dispositivo fue creado exitosamente"
      end

      ####3
    end

    redirect_to @device, notice: @notice 
  end

  def removeRemoteAuxDeviceConfig
    @device = Device.find(params[:id])
    p @device
    account = Account.find(@device.vehicle.account_id)

    #Get registered devices
    configid_url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=getRemoteAuxDeviceConfig&objectno="+@device.vehicle.objectno+"&outputformat=json&columnfilter=configid,deviceid,channel")
    response = HTTP.get(configid_url)
    @hash = JSON.parse response

    if @hash.present?
      result =  @hash.select {|device| device["deviceid"] == @device.MAC_address }

      if result.empty?
        @notice = "No hay ningún dispositivo con este MAC Address registrado en este vehículo."
      else    
        #Remove device
        removedevice_url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=removeRemoteAuxDeviceConfig&objectno="+@device.vehicle.objectno+"&outputformat=json&configid="+result.first['configid'].to_s)
        response = HTTP.get(removedevice_url)        
        @notice = "El dispositivo fue dado de baja con éxito."
      end

    #No devices registered at all - device will be created
    else
      @notice = "No hay ningún dispositivo registrado en este vehiculo."
    end

    redirect_to @device, notice: @notice 
  end

  def send_message_to_device
    @device = Device.find(params[:id])    
    account = Account.find(@device.vehicle.account_id)
    envio = "KO"

    p params[:message]
    data = Base64.strict_encode64(params[:message])
    p data

    @RS = params[:message][0..4]

    if ( @RS == "RS201"|| @RS == "RS202")

      @RFIDs = params[:message][6..-2].split(',')
      p "Cantidad de tarjetas: "+@RFIDs.size.to_s
      p "Cantidad de mensajes: "+(@RFIDs.size / 6.0).ceil.to_s
      @RFID_group_keys = ""
      n = 1

      @RFIDs.each do |key|

        @RFID_group_keys = @RFID_group_keys +"," + key

        if ( n % 6 == 0 || key == @RFIDs.last)

          #Send data to device
          p @RS+@RFID_group_keys+"*"
          data = Base64.strict_encode64(@RS+@RFID_group_keys+"*")
          send_data_url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=sendAuxDeviceData&objectno="+@device.vehicle.objectno+"&deviceid="+@device.MAC_address+"&data="+data)
          p send_data_url
          HTTP.get(send_data_url)
          envio = "OK"
          @RFID_group_keys = ""
          p n
          sleep 8
          p "Sleep 8 second..."
        end
        n=n+1
      end

    else
      #Send data to device
      send_data_url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=sendAuxDeviceData&objectno="+@device.vehicle.objectno+"&deviceid="+@device.MAC_address+"&data="+data)
      p send_data_url
      HTTP.get(send_data_url)
      envio = "OK"
    end

    if envio == "OK"
      #Create notification
      Notification.create(
          account_id: @device.vehicle.account_id,
          vehicle_id: @device.vehicle.id,
          device_id:  @device.id,
          objectno: @device.vehicle.objectno,
          text: "Se envío el mensaje de configuración remota '"+params[:message]+"' al dispositivo "+@device.name,
          tag: "RS",
          message_time: Time.now
      )

      #Get messages from WEBFLEET
      system "rake import:messages"

      redirect_to '/devices/'+params[:id], notice: "Messaje enviado."
      end
  end

  def verify_rfid_matches
    @device = Device.find(params[:id])

    if params[:original]
        
        #cargado
        cargado = ''
        m   = Message.select(:data).where(objectno: @device.vehicle.objectno).where("data like ?", "%RS206%").last(params[:msgid])
        m.each {|x|
          data1 = x.data[6..-2]
          comma = data1.index(',')
          data2 = data1[comma..-1]
          data3 = data2.gsub(/[*]/,'')
          cargado = cargado + data3.chomp('') }

        @array_cargado = cargado.split(/\s*,\s*/)
        @qty_cargado = (@array_cargado.size-1).to_s

        #Original
        original = params[:original]
        @array_original = original.split(/\s*,\s*/)
        @qty_original =@array_original.size.to_s

        #Diferencias
        @faltan = @array_original - @array_cargado
        @faltan_qty = @faltan.size.to_s

        #Sobran
        @sobran       = @array_cargado - @array_original
        @sobran_qty   = (@sobran.size-1).to_s
        @sobra_csv    = ''

        @sobran.each do |sobra|
          @sobra_csv = @sobra_csv+','+sobra
        end
    end
  end

  def new
    @device = Device.new
    @device.vehicle_id = params[:vehicle_id]
    @vehicles = Vehicle.joins(:account).where("accounts.wf_link_connect_account = ?", true).order('account_id ASC,objectno ASC')
    respond_with(@device)
  end

  def edit
    @vehicles = Vehicle.joins(:account).where("accounts.wf_link_connect_account = ?", true).order(:account_id, :objectno)
  end

  def create
    @device = Device.new(device_params)
    @device.created_by = current_user.id
    @device.updated_by = current_user.id

    @device.save
    respond_with(@device)
  end

  def update
    @device.updated_by = current_user.id
    @device.update(device_params)
    respond_with(@device)
  end

  def destroy
    @device.destroy
    respond_with(@device)
  end

  private
    def set_device
      @device = Device.find(params[:id])
    end

    def device_params
      params.require(:device).permit(:product, :name, :SN, :MAC_address, :HW_version, :FW_version, :vehicle_id, :last_message_received, :last_message_received_datetime, :created_by, :updated_by)
    end
end
