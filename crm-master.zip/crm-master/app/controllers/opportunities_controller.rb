class OpportunitiesController < ApplicationController
  before_action :set_opportunity, only: [:show, :edit, :update, :destroy]
  before_filter :locked_opportunity, only: [:edit, :update, :destroy]
  before_filter :admin_user

  respond_to :html

  def index
    @opportunities = Opportunity.all
    respond_with(@opportunities)
  end

  def show
    @notes = Textnote.where(opportunity_id: @opportunity.id)
    @audits = OpportunityAudit.where(opportunity_id: @opportunity.id)

    respond_with(@opportunity)

    #Recent items
    session[:recent_items] ||= Array.new     
    session[:recent_items].unshift("type" => "opportunities", "id" => @opportunity.id, "name" => @opportunity.name) 
    session[:recent_items] = session[:recent_items].uniq.first(5)

  end

  def new
    @opportunity = Opportunity.new
    @account = Account.find(params[:id])
    @opportunity.account_id = @account.id
    respond_with(@opportunity)
  end

  def edit
  end

  def create
    @opportunity = Opportunity.new(opportunity_params)
    @account = Account.find(@opportunity.account_id)

    @opportunity.created_by = current_user.id
    @opportunity.updated_by = current_user.id
    @opportunity.user_id    = current_user.id




    #Bloquear la oportunidad en caso de que el estado sea Ganada
    if (@opportunity.stage == 'Ganada') || (@opportunity.stage == 'Perdida')
        @opportunity.isLocked = true
      else
        @opportunity.isLocked = false
    end


    @opportunity.save
    respond_with(@opportunity)
  end

  def update
    @opportunity.update(opportunity_params)
    @opportunity.updated_by = current_user.id
   
    #Bloquear la oportunidad en caso de que el estado sea Ganada
    if (@opportunity.stage == 'Ganada') || (@opportunity.stage == 'Perdida')
        @opportunity.isLocked = true
      else
        @opportunity.isLocked = false
    end
      
    respond_to do |format|
      if @opportunity.update(opportunity_params)
        format.html { redirect_to @opportunity, notice: 'La oportunidad se edito exitosamente' }
        format.json { render :show, status: :ok, location: @opportunity }
      else
        format.html { render :edit }
        format.json { render json: @opportunity.errors, status: :unprocessable_entity }
      end
    end

  end

  def destroy
    @opportunity.destroy
    respond_with(@opportunity)
  end

  private
    def set_opportunity
      @opportunity = Opportunity.find(params[:id])
    end

    def opportunity_params
      params.require(:opportunity).permit(:name, :amount, :description, :stage, :close_date, :account_id, :user_id, :type, :created_at, :created_by, :updated_at, :updated_by, :isLocked)
    end

    #Protege a los metodos para que una oportunidad no se editada o borrada si esta bloqueada.
    def locked_opportunity
      if @opportunity.isLocked
        redirect_to(root_path) and return  
      end
    end
end
