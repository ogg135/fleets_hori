class VehiclesController < ApplicationController
  before_action :set_vehicle, only: [:show, :edit, :update, :destroy]
  before_filter :admin_user, only: [ :new, :edit, :create, :update, :destroy, :routeOptimization, :get_vehicles]



  respond_to :html

  def index
    
    if current_user.admin?
      @vehicles = Vehicle.search(params[:search]).order("objectno ASC")
      else
      @vehicles = Vehicle.where(account_id: current_user.account_id).search(params[:search]).order("objectno ASC")
    end
    respond_with(@vehicles)

  end

  def show
    @devices = Device.where(vehicle_id: @vehicle.id)
    respond_with(@vehicle)

    #Recent items
    session[:recent_items] ||= Array.new     
    session[:recent_items].unshift("type" => "vehicles", "id" => @vehicle.id, "name" => @vehicle.objectno) 
    session[:recent_items] = session[:recent_items].uniq.first(5)
  end

  def new
    @vehicle = Vehicle.new
    respond_with(@vehicle)
  end

  def edit
  end

  def create
    @vehicle = Vehicle.new(vehicle_params)
    @vehicle.save
    respond_with(@vehicle)
  end

  def update
    @vehicle.update(vehicle_params)
    respond_with(@vehicle)
  end

  def get_vehicles
    @account = Account.find(params[:id])
    system "rake import:vehicles"
    redirect_to @account, notice: 'Vehicles updated.' 
  end

  def deleteAllDevices
    @vehicle  = Vehicle.find(params[:id])
    account   = Account.find(@vehicle.account_id)

    configid_url  = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=getRemoteAuxDeviceConfig&objectno="+@vehicle.objectno+"&outputformat=json&columnfilter=configid")
    response      = HTTP.get(configid_url)
    @hash         = JSON.parse response

    if @hash.empty?
        @notice = "No hay dispositivos registrados en este vehiculo."
    else
      (0..4).each do |i|
        removedevice_url  = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=removeRemoteAuxDeviceConfig&objectno="+@vehicle.objectno+"&outputformat=json&configid="+i.to_s)
        response          = HTTP.get(removedevice_url)    
      end

      configid_url  = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+account.wf_account_name+"&username="+account.wf_username+"&password="+account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=getRemoteAuxDeviceConfig&objectno="+@vehicle.objectno+"&outputformat=json&columnfilter=configid")
      response      = HTTP.get(configid_url)
      @hash         = JSON.parse response

      if @hash.empty?
        @notice = "Los dispositivos fueron dados de baja con éxito."
      end

    end

    redirect_to @vehicle, notice: @notice 
    
  end

  def destroy
    @vehicle.destroy
    respond_with(@vehicle)
  end

  def nearestVehicle
    require 'csv'

    if current_user.admin?
      @all_addresses = Address.where.not('positionx' => nil).where.not('positiony' => nil)
      else
      @all_addresses = Address.where(account_id: current_user.account_id).where.not('positionx' => nil).where.not('positiony' => nil)
    end


    if params[:id]    
      @address = Address.find(params[:id])
      vehicleResponse = HTTP.get("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@address)+"&action=showNearestVehicles&addrno="+@address.addrnr.to_s+"&priority=2&separator=3&columnfilter=objectno,routedistance,routetime,latitude,longitude")
      @vehicles = CSV.parse(vehicleResponse.to_s).drop(1).first(5)
      respond_with(@vehicles, @address)

    end
  end


  def vehicleTrack
    require 'json'
    require 'csv'

    if current_user.admin?
      @all_vehicles = Vehicle.all.order(:account_id, :objectno)
      else
      @all_vehicles = Vehicle.where(account_id: current_user.account_id)
    end
    
    #If there is a vehicle selected
    if params[:search]

      #Search for the vehicle
      @vehicle = Vehicle.find(params[:search])

      #Temporary fixed params
      params[:dateRange] = 'userDefined'
      #If the date range selected is defined by the user
      if params[:dateRange] == 'userDefined'

        

        if params[:rangefrom_string] != ''

          from = params[:rangefrom_string].to_date.strftime('%d/%m/%Y')+"%2000:00:01"
          to = params[:rangefrom_string].to_date.strftime('%d/%m/%Y')+"%2023:59:59"

          p "https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTripSummaryReportExtern&objectuid="+@vehicle.objectuid+"&separator=3&useUTF8=true&columnfilter=start_time,end_time,distance,triptime,operatingtime,standstill,tours,fuel_usage&rangefrom_string="+from+"&rangeto_string="+to
          summaryResponse = HTTP.get("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTripSummaryReportExtern&objectuid="+@vehicle.objectuid+"&separator=3&useUTF8=true&columnfilter=start_time,end_time,distance,triptime,operatingtime,standstill,tours,fuel_usage&rangefrom_string="+from+"&rangeto_string="+to)
          p summaryResponse

          @tripsSummary = CSV.parse(summaryResponse.to_s).drop(1).first
          p @tripsSummary

        else

        end
        
      #Else if the date range selected is system defined
      else
        p "https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTripSummaryReportExtern&objectuid="+@vehicle.objectuid+"&separator=3&columnfilter=start_time,end_time,distance,triptime,operatingtime,standstill,tours,fuel_usage&range_pattern="+params[:dateRange]
        summaryResponse = HTTP.get("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTripSummaryReportExtern&objectuid="+@vehicle.objectuid+"&separator=3&columnfilter=start_time,end_time,distance,triptime,operatingtime,standstill,tours,fuel_usage&range_pattern="+params[:dateRange])
        p summaryResponse
        @tripsSummary = CSV.parse(summaryResponse.to_s).drop(1).first
      end

      #If tripsSummary contains no information do nothing
      if @tripsSummary.blank?
      else
        #Get vehicle trips
        if params[:dateRange] == 'userDefined'
          tripsResponse = HTTP.get("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTripReportExtern&objectuid="+@vehicle.objectuid+"&separator=3&columnfilter=start_time,start_postext,end_time,end_postext,distance,duration&rangefrom_string="+from+"&rangeto_string="+to)
        else
          tripsResponse = HTTP.get("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTripReportExtern&objectuid="+@vehicle.objectuid+"&separator=3&columnfilter=start_time,start_postext,end_time,end_postext,distance,duration&range_pattern="+params[:dateRange])
        end

        @vehicleTrips = CSV.parse(tripsResponse.to_s).drop(1).reverse

        #Get vehicle positions
        if params[:dateRange] == 'userDefined'
          trackResponse = HTTP.get("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTracks&objectuid="+@vehicle.objectuid+"&separator=3&columnfilter=latitude,longitude&rangefrom_string="+from+"&rangeto_string="+to)
        else
          trackResponse = HTTP.get("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTracks&objectuid="+@vehicle.objectuid+"&separator=3&columnfilter=latitude,longitude&range_pattern="+params[:dateRange])
        end

        @vehicleTrack = CSV.parse(trackResponse.to_s).drop(1)

        @points = ""
        n = 0
        areano = 114
        requests = 0

        p @vehicleTrack.size
        p @vehicleTrack.size/200

        #Build URL for CSV Export
        @CSV_link = "https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTracks&objectuid="+@vehicle.objectuid+"&separator=3&columnfilter=pos_time,receivetime,latitude,longitude,speed,course,odometer&rangefrom_string="+from+"&rangeto_string="+to
        


        #Convert positions to an Array
        @hash = Gmaps4rails.build_markers(@vehicleTrack) do |track, marker|
          marker.lat (track[0].to_f/1000000)
          marker.lng (track[1].to_f/1000000)
        end

          #Get gmap bounds
          @sw = {:lat =>  @hash.map { |lat| lat[:lat] }.min, :lng => @hash.map { |lon| lon[:lng] }.min}.to_json
          @ne = {:lat =>  @hash.map { |lat| lat[:lat] }.max, :lng => @hash.map { |lon| lon[:lng] }.max}.to_json

          #Convert array to json
          @hashJSON = @hash.to_json
          @hashJSON.gsub!(/\"/, '\'')  
      end
    end
      respond_with(@vehicle)
  end

  def convertTrackToArea
      flash[:notice] = "Creando areas en WEBFLEET"

      #Search for the vehicle
      @vehicle = Vehicle.find(params[:search])

      from = params[:rangefrom_string].to_date.strftime('%d/%m/%Y')+"%2000:00:01"
      to = params[:rangefrom_string].to_date.strftime('%d/%m/%Y')+"%2023:59:59"

      trackResponse = HTTP.get("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTracks&objectuid="+@vehicle.objectuid+"&separator=3&columnfilter=latitude,longitude&rangefrom_string="+from+"&rangeto_string="+to)
      @vehicleTrack = CSV.parse(trackResponse.to_s).drop(1)
      p (@vehicleTrack.size/200.to_f).ceil

        @areano   = params[:areano].to_i
        @areaname = params[:areaname]
        @points = ""
        n = 0
        requests = 1

        @vehicleTrack.each do |position|

          @points =  @points+"&point="+position[0]+","+position[1]
          n = n+1 
          p n
          
          if (n % 200 == 0) || (n == @vehicleTrack.size)
            p "Listo para el request no. "+requests.to_s
            p "Puntos: "+n.to_s
            url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=insertArea&areano="+@areano.to_s+"&areaname="+@areaname.to_s+"&type=4&width=400&notification-mode=1&eventlevel_leave=3&color=FF0000"+@points.to_s)
            p url
            request = HTTP.get(url)
            @points = ""

            #Create notification
            Notification.create(
                        account_id: @vehicle.account_id,
                        text: current_user.first_name+"(ID: "+current_user.id.to_s+") ha creado un area de tipo pasillo: "+@areano.to_s+"-"+@areaname+".",
                        tag: "Area",
                        message_time: Time.now
                    )

            #Add 1 to area
            @areano = @areano+1

            
            #After 10 request, wait 70 seconds before the next request. Allow time to reset the API limits. 
            if requests % 10 == 0
              sleep 70
            end
            requests = requests + 1

          end  
        end

        redirect_to '/vehicleTrack', notice: "Areas creadas."
  end

  def update_wakeup_timers
    Vehicle.update('lib/datasets/updateWakeUptimers7.csv')
    redirect_to root_url, notice: "Timers updated."
  end

  def routeOptimization

    @vehicles = Vehicle.all

    if params[:objectno]    
      @vehicle = Vehicle.where(objectno: params[:objectno]).first

        if params[:range_pattern].present?
        else
          params[:range_pattern] = 'd0'
        end

        #Get Standstills from WF
        p "Start task->"
        standstill_URL = "https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showStandStills&outputformat=json&range_pattern="+params[:range_pattern]+"&objectno="+params[:objectno]
        p standstill_URL
        standstill = HTTP.get(standstill_URL)
        @hash = JSON.parse standstill
        @Qty_standstills = @hash.size

        #Get Trips Summary from WF
        tripsSummary_URL = "https://csv.business.tomtom.com/extern?lang=en&"+wf_authenticate(@vehicle)+"&action=showTripSummaryReportExtern&outputformat=json&range_pattern="+params[:range_pattern]+"&objectno="+params[:objectno]
        p 'Trips Summary: '
        p tripsSummary_URL
        tripsSummary = HTTP.get(tripsSummary_URL)
        @ts = JSON.parse tripsSummary
        @distance_travelled = @ts.first['distance']/1000

        #Plot orignial standstills map
        markers = ''
        path = 'path=color:0x0000ff|weight:5'
        last_marker = ''
        n = 0
        index = ('A'..'Z').to_a

        #Build coordinates string for Google Maps API
        @hash.each do |standstill|
          markers = markers+'markers=label:'+index[n].to_s+"|"+(standstill['latitude'].to_f/1000000).to_s+","+(standstill['longitude'].to_f/1000000).to_s+"&"
          last_marker = (standstill['latitude'].to_f/1000000).to_s+"|"+(standstill['longitude'].to_f/1000000).to_s
          path = path+'|'+(standstill['latitude'].to_f/1000000).to_s+","+(standstill['longitude'].to_f/1000000).to_s
          n = n + 1
        end

        p "MArkers:"
        p markers

        @original_route = "https://maps.googleapis.com/maps/api/staticmap?visible="+last_marker+"&size=1600x1200&maptype=roadmap&"+markers+path
        p "Original Route->"
        p @original_route

        #Build coordinates string for TT MAP API
        cordenadas = ""
        @hash.each do |standstill|
          cordenadas = cordenadas+(standstill['latitude'].to_f/1000000).to_s+','+(standstill['longitude'].to_f/1000000).to_s+':'
        end

        #Build optimized route
        @waypoints_URL                = 'https://api.tomtom.com/routing/1/calculateRoute/'+cordenadas+'/json?routeType=shortest&computeBestOrder=true&key=nh9afc8cunyznetpsje87xxp'
        p "Waypoints URL: "
        p @waypoints_URL
        @waypoints                    = HTTP.get(@waypoints_URL)
        @optimized_results            = JSON.parse @waypoints
        @optimized_distance_travelled = @optimized_results['routes'].first['summary']['lengthInMeters']/1000
        @optimized_distance_percent   = ((@distance_travelled - @optimized_distance_travelled)/@distance_travelled.to_f).round(2) * 100 

        #Plot optimized route
        optimized_markers = ''
        optimized_path = 'path=color:0x0000ff|weight:5'
        n = 0
        p @optimized_results['optimizedWaypoints']
        size = @optimized_results['optimizedWaypoints'].size
        p "Size"+size.to_s

        while n < size
          #Start point
          if n == 0
              optimized_markers = 'markers=label:A|'+(@hash.first['latitude'].to_f/1000000).to_s+","+(@hash.first['longitude'].to_f/1000000).to_s+"&"
              optimized_path = optimized_path+'|'+(@hash.first['latitude'].to_f/1000000).to_s+","+(@hash.first['longitude'].to_f/1000000).to_s
          end

          #Loop to add optimized point
          @optimized_results['optimizedWaypoints'].each do |wp|
            if wp['optimizedIndex'] == n
              optimized_markers = optimized_markers+'markers=label:'+index[n+1].to_s+"|"+(@hash[wp['providedIndex']+1]['latitude'].to_f/1000000).to_s+","+(@hash[wp['providedIndex']+1]['longitude'].to_f/1000000).to_s+"&"
              optimized_path    = optimized_path+'|'+(@hash[wp['providedIndex']+1]['latitude'].to_f/1000000).to_s+","+(@hash[wp['providedIndex']+1]['longitude'].to_f/1000000).to_s
            end
          end

          #End Point
          if n == size-1
            optimized_markers = optimized_markers+'markers=label:'+index[n+2].to_s+'|'+(@hash.last['latitude'].to_f/1000000).to_s+","+(@hash.last['longitude'].to_f/1000000).to_s+"&"

            optimized_path = optimized_path+'|'+(@hash.last['latitude'].to_f/1000000).to_s+","+(@hash.last['longitude'].to_f/1000000).to_s
          end

          n = n + 1
        end

        p optimized_markers

        p "Printing optimized route ->"
        @optimized_route = "https://maps.googleapis.com/maps/api/staticmap?visible="+last_marker+"&size=1600x1200&maptype=roadmap&"+optimized_markers+optimized_path
        p @optimized_route

    end
  end

  def routePlanner

    #Get Orderd from WF
    if params[:range_pattern]  

      #Get orders from WF
      orders_url = "https://csv.business.tomtom.com/extern?lang=en&account=870006&username=Lut&password=tomtom&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0&action=showOrderReportExtern&outputformat=json&range_pattern="+params[:range_pattern]
      p orders_url
      orders = HTTP.get(orders_url)
      @orders = JSON.parse orders
      p @orders


      #Plot order in the map
      markers = ''
      path = 'path=color:0x0000ff|weight:5'
      last_marker = ''
      n = 0
      index = ('A'..'Z').to_a

      #Build coordinates string for Google Maps API
      @orders.each do |order|
        markers = markers+'markers=label:'+index[n].to_s+"|"+(order['latitude'].to_f/1000000).to_s+","+(order['longitude'].to_f/1000000).to_s+"&"
        last_marker = (order['latitude'].to_f/1000000).to_s+"|"+(order['longitude'].to_f/1000000).to_s
        path = path+'|'+(order['latitude'].to_f/1000000).to_s+","+(order['longitude'].to_f/1000000).to_s
        n = n + 1
      end

      @orders_plot = "https://maps.googleapis.com/maps/api/staticmap?visible="+last_marker+"&size=1600x1200&maptype=roadmap&"+markers+path
    end

    if params[:commit]
      @selected_orders = params[:selected_orders]
    end
  end

  private
    def set_vehicle
      @vehicle = Vehicle.find(params[:id])
    end

    def vehicle_params
      params.require(:vehicle).permit(:objectno, :objectname, :objectuid)
    end
end
