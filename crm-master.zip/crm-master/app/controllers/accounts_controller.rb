class AccountsController < ApplicationController
  before_action :set_account, only: [:show, :edit, :update, :destroy]
  before_filter :admin_user

  # GET /accounts
  # GET /accounts.json
  def index
    @accounts = Account.all
  end

  # GET /accounts/1
  # GET /accounts/1.json
  def show
    @vehicles = Vehicle.where(account_id: @account.id ).order(pos_time: :asc)
    @drivers = Driver.where(account_id: @account.id ).order(name1: :asc)
    @opportunities = Opportunity.where(account_id: @account.id )
    @notes = Textnote.where(account_id: @account.id)

    #Recent items
    session[:recent_items] ||= Array.new     
    session[:recent_items].unshift("type" => "accounts", "id" => @account.id, "name" => @account.name) 
    session[:recent_items] = session[:recent_items].uniq.first(5)
  end



  # GET /accounts/new
  def new
    @account          = Account.new
    @account.owner    = current_user.id
  end

  # GET /accounts/1/edit
  def edit
  end

  # POST /accounts
  # POST /accounts.json
  def create
    @account = Account.new(account_params)
    @account.created_by = current_user.id
    @account.updated_by = current_user.id
    @account.owner      = current_user.id

    respond_to do |format|
      if @account.save
        format.html { redirect_to @account, notice: 'Account was successfully created.' }
        format.json { render :show, status: :created, location: @account }
      else
        format.html { render :new }
        format.json { render json: @account.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /accounts/1
  # PATCH/PUT /accounts/1.json
  def update

    @account.updated_at = Time.now
    @account.updated_by = current_user.id


    respond_to do |format|
      if @account.update(account_params)
        format.html { redirect_to @account, notice: 'Account was successfully updated.' }
        format.json { render :show, status: :ok, location: @account }
      else
        format.html { render :edit }
        format.json { render json: @account.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /accounts/1
  # DELETE /accounts/1.json
  def destroy
    @account.destroy
    respond_to do |format|
      format.html { redirect_to accounts_url, notice: 'Account was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_account
      @account = Account.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def account_params
      params.require(:account).permit(:created_by, :name, :external_id, :owner, :website, :email, :phone, :updated_by, 
      :wf_account_name, :wf_username, :wf_password, :wf_import_vehicles, :wf_import_addresses, :wf_import_drivers, :wf_link_connect_account, 
      :service_temperature, :service_vehicle_track, :service_convert_track_into_area, 
      :temperature_min_threshold, :temperature_max_threshold, :temperature_create_notification_if_out_of_threshold, :temperature_send_email_notification, :temperature_notification_timer)
    end
end
