class DriversController < ApplicationController
  before_filter :admin_user, only: [:read_card, :write_card]

  respond_to :html
  require 'rubyserial'


	def index
		if current_user.admin?
			@drivers = Driver.search(params[:search])
		else
			@drivers = Driver.where(account_id: current_user.account_id).search(params[:search]).order(:name1)
		end
  	end

  	def drivers_access
  		@drivers = Driver.where(account_id: current_user.account_id).order(:name1)
  	end

  	def set_access

  		redirect_to '/drivers_access', notice: "Permisos enviados."
  		
  	end

  def get_drivers
    #@account = Account.find(params[:id])
    system "rake import:drivers"
    redirect_to '/drivers', notice: 'Conductores actualizados.' 
  end

	def read_card
	  	@data =''

	  	if params[:action] == 'read'
		  	sp = Serial.new '/dev/tty.usbmodemfd121', 9600
			sp.read_timeout = 1500
			p sp.gets.chomp
			@data = sp.gets.chomp
			p @data
			sp.close
	  	end
		end
  

  def write_card

  	sp = Serial.new '/dev/tty.usbmodemfd121', 9600
	p sp.write('hola')
	sp.write('hola')
	p 'antes'
	sleep(5)
	sp.read(5)
	p sp.read(5)
	p 'despues'
	#sp.close

  	redirect_to '/read_card', notice: "Familias guardadas en la tarjeta"
  end

end
