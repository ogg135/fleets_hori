class NotificationsController < ApplicationController
  before_action :set_notification, only: [:show, :edit, :update, :destroy]
  before_filter :admin_user, only: [:edit, :update, :destroy]

  respond_to :html

  def index
    if current_user.admin?
      @notifications = Notification.by_tag_account_and_objectno(params[:tag], params[:account], params[:objectno], params[:message_time]).reverse.last(1000)
      @accounts = Notification.select(:account_id).distinct.reverse.last(50)
      @vehicles = Notification.select(:objectno).distinct.reverse.last(50)
    else
      @notifications = Notification.where(:account_id == current_user.account_id).by_tag_account_and_objectno('Temperature', nil, params[:objectno], params[:message_time]).reverse.last(1000)
      @vehicles = Notification.where(:account_id == current_user.account_id).select(:objectno).distinct.last(50)
    end
    respond_with(@notifications)
  end

  def show
    respond_with(@notification)
  end

  def new
    @notification = Notification.new
    respond_with(@notification)
  end

  def edit
  end

  def create
    @notification = Notification.new(notification_params)
    @notification.save

    respond_with(@notification)
  end

  def update
    @notification.update(notification_params)
    respond_with(@notification)
  end

  def destroy
    @notification.destroy
    respond_with(@notification)
  end

  private
    def set_notification
      @notification = Notification.find(params[:id])
    end

    def notification_params
      params[:notification]
    end
end
