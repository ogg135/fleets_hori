class OpportunityAuditsController < ApplicationController

  respond_to :html

  def new
    @opportunity_audit = OpportunityAudit.new
    respond_with(@opportunity_audit)
  end


  def create
    @opportunity_audit = OpportunityAudit.new(opportunity_audit_params)
    @opportunity_audit.save
    respond_with(@opportunity_audit)
  end


  private
    def set_opportunity_audit
      @opportunity_audit = OpportunityAudit.find(params[:id])
    end

    def opportunity_audit_params
      params[:opportunity_audit]
    end
end
