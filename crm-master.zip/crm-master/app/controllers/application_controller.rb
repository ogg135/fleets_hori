class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception
  before_filter :authenticate_user! 
	before_filter :configure_permitted_parameters, if: :devise_controller?

  helper_method :wf_authenticate

  def wf_authenticate(object)
    
    if current_user.admin?
        wf_authenticated = "account="+object.account.wf_account_name+"&username="+object.account.wf_username+"&password="+object.account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0"
      else    
        wf_authenticated = "account="+current_user.account.wf_account_name+"&username="+current_user.account.wf_username+"&password="+current_user.account.wf_password+"&apikey=3f908e18-f6f5-4c71-b86e-f95c2ffea8f0"
    return wf_authenticated
    end
  end




	def admin_user
      redirect_to(root_path) unless current_user.admin?
   	end


  	protected

	def configure_permitted_parameters
		devise_parameter_sanitizer.for(:sign_up) << :first_name
		devise_parameter_sanitizer.for(:sign_up) << :last_name

    devise_parameter_sanitizer.for(:account_update) << :first_name
    devise_parameter_sanitizer.for(:account_update) << :last_name
	end

end
