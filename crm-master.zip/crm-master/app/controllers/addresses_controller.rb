class AddressesController < ApplicationController
  before_action :set_address, only: [:show, :edit, :update, :destroy]
  before_filter :admin_user 

  respond_to :html

  require 'csv'
  require 'net/http'


  def index
    @addresses = Address.all
    respond_with(@addresses)
  end

  def show
    respond_with(@address)
  end

  def new
    @address = Address.new
    respond_with(@address)
  end

  def edit
  end

  def create
    @address = Address.new(address_params)
    @address.save
    respond_with(@address)
  end

  def update
    @address.update(address_params)
    respond_with(@address)
  end

  def destroy
    @address.destroy
    respond_with(@address)
  end


  def importar
  end

  def insert_addresses_to_WF

    @n  = 0
    @ok = 0
    @ko = 0
    flash[:error] = []

    CSV.foreach(params[:file].path, headers: true) do |row|

      #Contador
      @n = @n + 1
      
      #Request
      url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account=870006&username=Lut&password=tomtom&apikey=2a600645-e4c5-4e50-b875-e0780bfc2157&action=insertAddressExtern&addrnr="+row["addrnr"].to_s+"&addrname1="+row["addrname1"].to_s+"&addrname2="+row["addrname2"].to_s+"&addrname3="+row["addrname3"].to_s+"&addrstate="+row["addrstate"].to_s+"&addrzip="+row["addrzip"].to_s+"&addrcity="+row["addrcity"].to_s+"&addrstreet="+row["addrstreet"].to_s+"&addrinfo="+row["addrinfo"].to_s+"&mailaddr="+row["mailaddr"].to_s+"&radius="+row["radius"].to_s+"&visible="+row["visible"].to_s+"&color="+row["color"].to_s+"&addrregion="+row["addrregion"].to_s+"&positiony="+row["positiony"].to_s+"&positionx="+row["positionx"].to_s+"&addrgrpname="+row["addrgrpname"].to_s)
      response = HTTP.get(url)

          #Check if there is a repsonse
          if response.present?
            p response 
            response = CSV.parse(response.to_s)
            p response

            #Chech if response contains errors
            if response.present?
              @ko = @ko + 1
              flash[:error] << "addrnr: "+row["addrnr"].to_s+','+"Error: "+response[0][1].to_s
            else
              #No errors 
              @ok = @ok + 1  
            end
          end
    end

    if @ko == 0
      redirect_to importar_path, notice: @n.to_s+" direccion(es) leida(s), "+@ok.to_s+ " insertada(s)."
    else
      flash[:notice]  = @n.to_s+" direccion(es) leida(s), "+@ok.to_s+ " insertada(s) y "+@ko.to_s+" error(es)."
      #flash[:error]   = @error_list.map {|a| %Q("#{a}")}.join()
      redirect_to importar_path
    end

  end

  def geocode_addresses
    Address.geocode('lib/datasets/Direcciones_IZZI_CERCOS.csv')
    redirect_to importar_path, notice: "Addresses Geocoded."
  end

  private
    def set_address
      @address = Address.find(params[:id])
    end

    def address_params
      params.require(:address).permit(:addrnr, :addruid, :addrname1, :radius, :positiony, :positionx, :mapcode, :account_id)
    end
end
