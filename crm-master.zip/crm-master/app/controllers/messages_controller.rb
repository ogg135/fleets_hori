class MessagesController < ApplicationController
  before_action :set_message, only: [:show, :edit, :update, :destroy]
  before_filter :admin_user
  respond_to :html

  def index
    @messages = Message.where(nil).reverse.last(1000) # creates an anonymous scope
    @messages = Message.where("message_time >= :date", :date => params[:message_time].to_i.days.ago).reverse.last(1000) if params[:message_time].present?
    respond_with(@messages)
  end

  def show
    respond_with(@message)
  end

  def new
    @message = Message.new
    respond_with(@message)
  end

  def edit
  end

  def create
    @message = Message.new(message_params)
    @message.save
    respond_with(@message)
  end

  def update
    @message.update(message_params)
    respond_with(@message)
  end

  def destroy
    @message.destroy
    respond_with(@message)
  end

  def get_messages
    system "rake import:messages"
    flash[:notice] = "Importing messages from WF"
    redirect_to '/messages?message_time=1', notice: "Messages updated."
  end

  private
    def set_message
      @message = Message.find(params[:id])
    end

    def message_params
      params.require(:message).permit(:account_id, :vehicle_id, :wf_message_id, :message_time, :data, :device_type, :created_at, :updated_at, :longitud, :latitude, :pos_time, :source_device_address, :temperature_C)
    end
end
