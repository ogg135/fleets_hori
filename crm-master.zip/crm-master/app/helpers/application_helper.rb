module ApplicationHelper


#To avoid repeating date ranges
# Before example vehicleTrack.html.erb: <%= f.input :dateRange, collection: {'Hoy' => 'd0','Ayer' => 'd-1'}, :label => 'Fecha', :selected => params[:search] %>
	def date_range_options
	  [
	    ["Hoy", "d0"],
	    ["Ayer", "d-1"],
	    ["Antier", "d-2"],
	    ["Hace 3 días", "d-3"],
	    ["Hace 4 días", "d-4"],
	    ["Hace 5 días", "d-5"],
	    ["Hace 6 días", "d-6"],
	    ["Definir fecha", "userDefined"]
	  ]
	end


end
