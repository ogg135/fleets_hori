module DevicesHelper

	#LINK Connect commands ICE
	def remote_setup_commands_ICE
		[
			#General - All devices
			["RS001 - Envio de version FW","RS001"],
			["RS003 - Act ahorro de energia ","RS003"],
			["RS004 - Desact ahorro de energia","RS004"],
			["RS005 - Soft Reset","RS005"],
			["RS006 - Hard Reset","RS006"],
		]
		
	end

	#LINK Connect commands RFID
	def remote_setup_commands_RFID
		[
			#General - All devices
			["RS001 - Envio de version FW","RS001"],
			["RS002 - Sends the current values of the RS","RS002"],
			["RS003 - Act ahorro de energia ","RS003"],
			["RS004 - Desact ahorro de energia","RS004"],
			["RS005 - Soft Reset","RS005"],
			["RS006 - Hard Reset","RS006"],

			#RFID
			["RS201 - Alta tarjeta(s)","RS201"],
			["RS202 - Baja tarjeta(s)","RS202"],
			["RS203 - Alta tarjeta(s) maestra","RS203"],
			["RS204 - Baja tarjeta(s) maestra","RS204"],
			["RS205 - Obtener tarjetas Maestras","RS205"],
			["RS206 - Obtener tarjetas","RS206"],
			["RS207 - Obtener no. total tarjetas","RS207"],
			["RS211 - Act msj cambiar de conductor","RS211"],
			["RS212 - Desact msj cambiar de conductor","RS212"],
			["RS213 - Act envio de no autorizados","RS213"],
			["RS214 - Desact envio de no autorizados","RS214"],
			["RS215 - Act relevador permanente","RS215"],
			["RS216 - Desact relevador permanente","RS216"],
			["RS217 - Timeout para modo configuracion","RS217"],
			["RS218 - Timeout to verify device is paired to LINK","RS218"],
			["RS219 - Timeout to close the relay","RS219"],
			["RS220 - Timeout para modo configuracion","RS220"],
			["RS221	- Timeout para terminar el enlace con LINK","RS221"],
			["RS222	- Desactivar: La conexión al LINK es permanente ","RS222"]
		]
		
	end

end
