class OpportunityObserver < ActiveRecord::Observer
  
	def after_create(opportunity)
		
	end

	def after_update(opportunity)

	   	#Crear un registro de cambio del importe en caso de que haya cambiado
	    if opportunity.amount_changed?
			@audit 					= OpportunityAudit.new
			@audit.opportunity_id 	= opportunity.id
			@audit.field          	= "amount"
			@audit.old_value		= opportunity.amount_was
			@audit.new_value      	= opportunity.amount
			@audit.user_id        	= opportunity.created_by
			@audit.save
	    end

	    #Crear un registro de cambio de la etapa en caso de que haya cambiado
	   	if opportunity.stage_changed?
			@audit 					= OpportunityAudit.new
			@audit.opportunity_id 	= opportunity.id
			@audit.field          	= "stage"
			@audit.old_value		= opportunity.stage_was
			@audit.new_value      	= opportunity.stage
			@audit.user_id        	= opportunity.created_by
			@audit.save
	    end

	end


end