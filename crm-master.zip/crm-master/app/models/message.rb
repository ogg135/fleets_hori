class Message < ActiveRecord::Base
	belongs_to :vehicle

	scope :temperature, -> { where(device_type: 'temperature') }
	scope :rfid, 		-> { where(device_type: 'RFID') }

	def self.to_csv
    	CSV.generate do |csv|
    		  csv << Message.attribute_names
			  Message.all.each do |message|
			    csv << message.attributes.values
			  end
	    end
	 end
end
