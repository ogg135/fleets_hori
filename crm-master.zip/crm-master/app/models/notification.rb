class Notification < ActiveRecord::Base
	belongs_to :account
	belongs_to :device
	belongs_to :user

	scope :tag, -> (tag) { where tag: tag }

	def self.by_tag_account_and_objectno(tag = nil, account = nil, objectno = nil, message_time = nil)
		#If 4
	    return where(tag: tag, account_id: account, objectno: objectno).where("message_time >= :date", :date => message_time.to_i.hours.ago) if tag && account && objectno && message_time
	    #If 3
	    return where(tag: tag, account_id: account, objectno: objectno) if tag && account && objectno
	    return where(tag: tag, objectno:   objectno).where("message_time >= :date", :date => message_time.to_i.hours.ago) if tag && objectno && message_time
	    return where(account: account, objectno:   objectno).where("message_time >= :date", :date => message_time.to_i.hours.ago) if account && objectno && message_time
	    #If 2
	    return where(tag: tag, account_id: account) if tag && account
	    return where(tag: tag, objectno: objectno) if tag && objectno
	    return where(tag: tag).where("message_time >= :date", :date => message_time.to_i.hours.ago) if tag && message_time
	    return where(account_id: account, objectno: objectno) if account && objectno
	    return where(account_id: account).where("message_time >= :date", :date => message_time.to_i.hours.ago) if account && message_time
	    return where(objectno: objectno).where("message_time >= :date", :date => message_time.to_i.hours.ago) if objectno && message_time
	    #If 1
		return where(tag: tag) if tag
	    return where(account_id: account) if account
	    return where(objectno: 	objectno) if objectno
	    return where("message_time >= :date", :date => message_time.to_i.hours.ago) if message_time
	    all
  	end

  	tags = ['temperature', 'No Circula'].freeze

end
