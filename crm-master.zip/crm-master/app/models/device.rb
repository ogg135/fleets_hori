class Device < ActiveRecord::Base

	belongs_to :vehicle
	belongs_to :account
	has_many :textnotes
	has_many :notifications

	#Validations
	validates 	:product, :presence => true
	validates 	:MAC_address, format: { with: /\A\h{2}([:\-]?\h{2}){5}\z|\A\h{2}([:\-]?\h{2}){7}\z/,
				message: "please enter a valid MAC address" }, uniqueness: true
	validates 	:HW_version, :presence => true
	validates 	:FW_version, :presence => true


	def self.to_csv
    	CSV.generate do |csv|
    		  csv << Device.attribute_names
			  Device.all.each do |device|
			    csv << device.attributes.values
			  end
	    end
	 end


end
