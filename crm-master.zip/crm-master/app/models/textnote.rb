class Textnote < ActiveRecord::Base
	acts_as_paranoid

	belongs_to :account
	belongs_to :opportunity
	belongs_to :user
	belongs_to :device

	#Validate Presence
	validates 	:title, :presence => true
	
end
