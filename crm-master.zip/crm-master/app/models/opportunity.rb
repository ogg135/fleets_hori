class Opportunity < ActiveRecord::Base
	include ActiveModel::Dirty
	acts_as_paranoid

	belongs_to :user
	belongs_to :account

	has_many :textnotes
	has_many :opportunity_audits



	#Validate Presence
	validates 	:name, :amount, :stage, :close_date, :account,     						
				:presence => true

	#Validates Positive 
	validates :amount, :numericality => { :greater_than_or_equal_to => 0 }	 




end
