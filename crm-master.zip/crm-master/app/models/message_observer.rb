class MessageObserver < ActiveRecord::Observer


end