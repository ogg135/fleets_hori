class Vehicle < ActiveRecord::Base

	belongs_to :account
	has_many :messages
	has_many :devices

  # It returns the address that matches with the objectno
  def self.search(query)
    # where(:objectno, query) -> This would return an exact match of the query
    where("objectno like ?", "%#{query}%") 
  end


  	def self.update(file)
		@n=1
		CSV.foreach(file, headers: true) do |row|

			p @n
			p row["objectuid"]
			
			url = URI.encode("https://csv.business.tomtom.com/extern?lang=en&account="+row["account"].to_s+"&username="+row["username"].to_s+"&password="+row["password"].to_s+"&apikey=2a600645-e4c5-4e50-b875-e0780bfc2157&action=updateWakeupTimers&objectuid="+row["objectuid"].to_s+"&sun=1&time1=03:00")
			p url

 
			begin
				request = HTTP.get(url)
			rescue Timeout::Error, Errno::EINVAL, Errno::ECONNRESET, EOFError,
			       Net::HTTPBadResponse, Net::HTTPHeaderSyntaxError, Net::HTTPConnectionError, Net::ProtocolError => e
			end

			if (@n % 10) == 0
				sleep(70)
			end
		
			@n = @n + 1



			
			
			
			if request.present?
				
				p request
			end


		end
	end


end
