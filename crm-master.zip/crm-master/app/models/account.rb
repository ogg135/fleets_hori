class Account < ActiveRecord::Base
	acts_as_paranoid
	
	has_many :users
	has_many :opportunities
	has_many :textnotes
	has_many :vehicles
	has_many :addresses
	has_many :notifications

	#Validate Presence
	validates 	:name,  						
				:presence => true

end
