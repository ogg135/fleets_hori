class Driver < ActiveRecord::Base
	belongs_to :account

	def self.search(query)
    	where("name1 like ?", "%#{query}%") 
  	end

end
