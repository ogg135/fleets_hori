class Address < ActiveRecord::Base
	belongs_to :account

#Codigo para exportar CSV

#	def self.to_csv(options = {})
#		CSV.generate(options) do |csv|
#			csv << column_names
#			all.eadh do |product|
#				csv << product.attributes.values_at(*column_names)
#			end
#		end
#	end


	def self.geocode(file)
		@n=0
		CSV.foreach(file, headers: true) do |row|

			encoded_url = URI.encode("http://maps.googleapis.com/maps/api/geocode/json?address="+row["addrinfo"].to_s)
			#p encoded_url
			uri = URI.parse(encoded_url)
			response = Net::HTTP.get(uri)

			hash = JSON.parse(response)

			if hash['status'] == 'OK'
				p row['addrnr'].to_s+','+hash['results'].first['geometry']['location']['lat'].to_s+','+hash['results'].first['geometry']['location']['lng'].to_s
			else
				p row['addrnr'].to_s+'SIN MATCH'
			end

		end
	end
end
