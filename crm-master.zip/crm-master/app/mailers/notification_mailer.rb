class NotificationMailer < ActionMailer::Base
  default from: 'Fleetr'

	def temperature_email(notification)
		@notification = notification
		mail(to: @notification.account.email, subject: @notification.objectno+" - "+@notification.text )
	end

	def device_not_registered_email(notification)
		@notification = notification
		mail(to: @notification.recipients, subject: @notification.text )
	end

	def no_cirula_tomorrow_email(alert_vehicles)
		@alert_vehicles = alert_vehicles
		mail()
	end


end
